#!/bin/sh

# Causal
cd ../..

python3 client_causal.py localhost

