#!/bin/sh

python3 client.py 0.0.0.0 6486 & python3 client.py 0.0.0.0 6486 & python3 client.py 0.0.0.0 6486 & python3 client.py 0.0.0.0 6486
